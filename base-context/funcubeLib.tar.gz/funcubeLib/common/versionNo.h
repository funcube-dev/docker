#pragma once 
// Changes will be overwritten, build generated file 
#define SVN_REV 11828 
#define SVN_REV_STR "1.1.828" 
#define SVN_DATE_STR "2020-05-15" 
#define SVN_TIME_STR "22:55:00" 
