# funcubeLib
decodes/encodes data from/for the FUNcube family of satellites, detects and tracks them too.
