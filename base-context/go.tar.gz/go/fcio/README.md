# github.com/funcube-dev/go/fcio
re-usable io utilities:
- TimedConn which wraps a connection to give a connection with read/write timeouts
- ReadSeekCloser wraps a ReadCloser to provide seeking if availabile on the underlying reader

